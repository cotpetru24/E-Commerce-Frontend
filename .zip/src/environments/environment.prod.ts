export const environment = {
  production: true,
  apiBaseUrl: 'https://production-api-here.com'
};