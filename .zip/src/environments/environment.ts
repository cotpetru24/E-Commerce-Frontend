export const environment = {
  production: false,
  apiBaseUrl: 'https://localhost:5001',
  stripePublishableKey:'pk_test_51Ply1TBlRu5FugfukzYTsihdCL7q6Kasdq8sDh9VcldWFTnh3c07OY1EMf7e3qqVon1YkIlZjMnNMt426yZBaS4f00GflfIjk1'
};