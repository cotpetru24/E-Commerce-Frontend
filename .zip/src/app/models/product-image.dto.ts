
export interface ProductImageDto{
    id:number,
    productId: number,
    imagePath:string,
    isPrimary:boolean,
    sortOrder:number
}