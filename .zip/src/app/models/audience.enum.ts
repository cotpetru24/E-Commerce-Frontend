export enum Audience {
  Men = 'men',
  Women = 'women',
  Children = 'children',
  Unisex = 'unisex'
}
