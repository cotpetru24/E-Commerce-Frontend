export interface OrderSummary {
  subtotal: number;
  discount: number;
  shipping: number;
  total: number;
}
