import { ComponentFixture, TestBed } from '@angular/core/testing';
import { AdminDashboardComponent } from './admin-dashboard.component';
import { AdminApiService } from '../../services/api/admin-api.service';
import { ToastService } from '../../services/toast.service';
import { UtilsService } from '../../services/utils.service';
import { Router } from '@angular/router';
import { of } from 'rxjs';

describe('AdminDashboardComponent', () => {
  let component: AdminDashboardComponent;
  let fixture: ComponentFixture<AdminDashboardComponent>;
  let mockAdminApiService: jasmine.SpyObj<AdminApiService>;
  let mockToastService: jasmine.SpyObj<ToastService>;
  let mockUtilsService: jasmine.SpyObj<UtilsService>;
  let mockRouter: jasmine.SpyObj<Router>;

  beforeEach(async () => {
    mockAdminApiService = jasmine.createSpyObj('AdminApiService', ['getDashboardStats']);
    mockToastService = jasmine.createSpyObj('ToastService', ['success', 'error']);
    mockUtilsService = jasmine.createSpyObj('UtilsService', ['formatCurrency', 'formatDate', 'getTimeAgo']);
    mockRouter = jasmine.createSpyObj('Router', ['navigate']);

    await TestBed.configureTestingModule({
      imports: [AdminDashboardComponent],
      providers: [
        { provide: AdminApiService, useValue: mockAdminApiService },
        { provide: ToastService, useValue: mockToastService },
        { provide: UtilsService, useValue: mockUtilsService },
        { provide: Router, useValue: mockRouter }
      ]
    }).compileComponents();

    fixture = TestBed.createComponent(AdminDashboardComponent);
    component = fixture.componentInstance;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('ngOnInit_ShouldLoadDashboardStats_WhenComponentInitializes', () => {
    const mockStats = {
      totalOrders: 100,
      totalRevenue: 5000,
      totalUsers: 50,
      totalProducts: 200
    };
    
    mockAdminApiService.getDashboardStats.and.returnValue(of(mockStats));
    
    component.ngOnInit();
    
    expect(mockAdminApiService.getDashboardStats).toHaveBeenCalled();
  });

  it('formatCurrency_ShouldReturnFormattedCurrency_WhenAmountIsProvided', () => {
    mockUtilsService.formatCurrency.and.returnValue('£50.00');
    
    const result = component.formatCurrency(50);
    
    expect(mockUtilsService.formatCurrency).toHaveBeenCalledWith(50);
    expect(result).toBe('£50.00');
  });
});
