import { Injectable } from '@angular/core';

/**
 * Shared utility service for common formatting and helper functions
 * Used across multiple components to avoid code duplication
 */
@Injectable({
  providedIn: 'root'
})
export class UtilsService {
  
  /**
   * Format a date to a localized date string
   */
  formatDate(date: Date | string): string {
    return new Date(date).toLocaleDateString();
  }

  /**
   * Format a number as currency (GBP)
   */
  formatCurrency(amount: number): string {
    return `£${amount.toFixed(2)}`;
  }

  /**
   * Format time ago string (e.g., "2 days ago", "Just now")
   * More detailed version with seconds/minutes/hours
   */
  formatTimeAgo(dateString: Date | string): string {
    const date = new Date(dateString);
    const now = new Date();
    const diffInSeconds = Math.floor((now.getTime() - date.getTime()) / 1000);

    if (diffInSeconds < 60) {
      return 'Just now';
    } else if (diffInSeconds < 3600) {
      const minutes = Math.floor(diffInSeconds / 60);
      return `${minutes} minute${minutes > 1 ? 's' : ''} ago`;
    } else if (diffInSeconds < 86400) {
      const hours = Math.floor(diffInSeconds / 3600);
      return `${hours} hour${hours > 1 ? 's' : ''} ago`;
    } else if (diffInSeconds < 2592000) {
      const days = Math.floor(diffInSeconds / 86400);
      return `${days} day${days > 1 ? 's' : ''} ago`;
    } else {
      return date.toLocaleDateString();
    }
  }

  /**
   * Get time ago string (simpler version with days/weeks/months/years)
   */
  getTimeAgo(date: Date | string): string {
    const now = new Date();
    const past = new Date(date);
    const diffInMs = now.getTime() - past.getTime();
    const diffInDays = Math.floor(diffInMs / (1000 * 60 * 60 * 24));
    
    if (diffInDays === 0) return 'Today';
    if (diffInDays === 1) return 'Yesterday';
    if (diffInDays < 7) return `${diffInDays} days ago`;
    if (diffInDays < 30) return `${Math.floor(diffInDays / 7)} weeks ago`;
    if (diffInDays < 365) return `${Math.floor(diffInDays / 30)} months ago`;
    return `${Math.floor(diffInDays / 365)} years ago`;
  }

  /**
   * Format time (HH:mm)
   */
  formatTime(date: Date | string): string {
    return new Date(date).toLocaleTimeString('en-GB', { 
      hour: '2-digit', 
      minute: '2-digit' 
    });
  }
}

