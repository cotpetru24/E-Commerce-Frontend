import { Injectable } from '@angular/core';
import { BaseApiService } from './base-api.service';
import { HttpClient } from '@angular/common/http';
import { StorageService } from '../storage.service';
import { CmsLandingPageDto, CmsNavAndFooterDto } from '../../models/cms.dto';
import { Observable, tap } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class CmsApiService extends BaseApiService {
  protected readonly baseUrl = '/api/Cms';

  constructor(
    protected override http: HttpClient,
    protected override storageService: StorageService
  ) {
    super(http, storageService);
  }

  GetCmsNavAndFooterAsync(): Observable<CmsNavAndFooterDto> {
    const url = this.buildUrl(this.baseUrl + '/navAndFooter');
    this.logRequest('GET', url);

    return this.get<CmsNavAndFooterDto>(url).pipe(
      tap((response) => this.logResponse('GET', url, response))
    );
  }

  getCmsLandingPageAsync(): Observable<CmsLandingPageDto> {
    const url = this.buildUrl(this.baseUrl + '/landing');
    this.logRequest('GET', url);

    return this.get<CmsLandingPageDto>(url).pipe(
      tap((response) => this.logResponse('GET', url, response))
    );
  }
}
