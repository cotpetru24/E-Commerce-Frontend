import { TestBed } from '@angular/core/testing';
import { CmsStateService } from './cmsStateService';

describe('CmsStateService', () => {
  let service: CmsStateService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CmsStateService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('setProfile_ShouldCacheProfile_WhenProfileIsSet', () => {
    const mockProfile = { websiteName: 'Test Store', tagline: 'Test Tagline' };
    
    service.setProfile(mockProfile);
    
    service.cmsProfile$.subscribe(profile => {
      expect(profile).toEqual(mockProfile);
    });
  });

  it('setProfile_ShouldApplyTheme_WhenProfileWithThemeIsSet', () => {
    const mockProfile = {
      navbarBgColor: '#1a1a1a',
      navbarTextColor: '#ffffff',
      footerBgColor: '#2a2a2a'
    };
    
    service.setProfile(mockProfile);
    
    service.cmsProfile$.subscribe(profile => {
      expect(profile?.navbarBgColor).toBe('#1a1a1a');
      expect(profile?.navbarTextColor).toBe('#ffffff');
    });
  });

  it('setProfile_ShouldHandleNull_WhenNullProfileIsSet', () => {
    service.setProfile(null);
    
    service.cmsProfile$.subscribe(profile => {
      expect(profile).toBeNull();
    });
  });
});
